<?php echo e($slot); ?>

<?php /**PATH C:\Users\ovi24\Documents\example-app\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>