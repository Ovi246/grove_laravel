<x-mail::message>


# New user subscribed 

Here is your subscriber details:

- Name: {{ $subscription->name }}
- Email: {{ $subscription->email }}

Stay tuned, ,<br>Thanks,<br>

</x-mail::message>
